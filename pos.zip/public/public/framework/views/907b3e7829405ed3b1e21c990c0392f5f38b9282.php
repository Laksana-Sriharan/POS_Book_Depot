<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> &copy; <a href="">Poobalasingham Book Depot</a> 
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-end footer-links d-none d-sm-block">
                                    <p><i class="fa-solid fa-location-dot"></i>&nbsp; 202, Sea street, Colombo-11, Sri Lanka<br>
                                    <i class="fa-solid fa-envelope"></i>&nbsp; Poobalasingham202@gmail.com &nbsp;
                                    <i class="fa-solid fa-phone"></i>&nbsp; Tel:- 2422321 , 2435713 &nbsp;
                                    <i class="fa-solid fa-fax"></i>&nbsp; Fax - 2337313</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer><?php /**PATH C:\S09_Project\pos\resources\views/body/footer.blade.php ENDPATH**/ ?>