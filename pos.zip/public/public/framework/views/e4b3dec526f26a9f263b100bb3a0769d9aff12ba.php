<?php $__env->startSection('admin'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

 <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a  class="btn btn-primary rounded-pill waves-effect waves-light text-light" href="<?php echo e(route('all.supplier')); ?>"><i class="fa-solid fa-angle-left"></i> &nbsp; Back </a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Details Supplier</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title -->

<div class="row">


  <div class="col-lg-8 col-xl-12">
<div class="card">
    <div class="card-body">





    <!-- end timeline content-->

    <div class="tab-pane" id="settings">
        <form method="post" action="<?php echo e(route('supplier.update')); ?>" enctype="multipart/form-data">
        	<?php echo csrf_field(); ?>

           <input type="hidden" name="id" value="<?php echo e($supplier->id); ?>"> 

            <h5 class="mb-4 text-uppercase"><i class="mdi mdi-account-circle me-1"></i> Details Supplier</h5>

            <div class="row">


    <div class="col-md-6">
        <div class="mb-3">
            <label for="firstname" class="form-label">Supplier Name</label>
            <p class="text-danger"><?php echo e($supplier->name); ?></p>
        </div>
    </div>


              <div class="col-md-6">
        <div class="mb-3">
            <label for="firstname" class="form-label">Supplier Email</label>
               <p class="text-danger"><?php echo e($supplier->email); ?></p>

        </div>
    </div>




              <div class="col-md-6">
        <div class="mb-3">
            <label for="firstname" class="form-label">Supplier Phone    </label>
             <p class="text-danger"><?php echo e($supplier->phone); ?></p>
        </div>
    </div>


      <div class="col-md-6">
        <div class="mb-3">
            <label for="firstname" class="form-label">Supplier Address    </label>
             <p class="text-danger"><?php echo e($supplier->address); ?></p>
        </div>
    </div>




      <div class="col-md-6">
        <div class="mb-3">
            <label for="firstname" class="form-label">Supplier Type   </label>
             <p class="text-danger"><?php echo e($supplier->type); ?></p>
        </div>
    </div>




     <div class="col-md-6">
        <div class="mb-3">
            <label for="firstname" class="form-label">Account Number    </label>

              <p class="text-danger"><?php echo e($supplier->account_number); ?></p>
        </div>
    </div>

      <div class="col-md-6">
        <div class="mb-3">
            <label for="firstname" class="form-label">Bank Name    </label>

              <p class="text-danger"><?php echo e($supplier->bank_name); ?></p>
        </div>
    </div>


      <div class="col-md-6">
        <div class="mb-3">
            <label for="firstname" class="form-label">Bank Branch    </label>

             <p class="text-danger"><?php echo e($supplier->bank_branch); ?></p>
        </div>
    </div>





            </div> <!-- end row -->


        </form>
    </div>
    <!-- end settings content-->


                                    </div>
                                </div> <!-- end card-->

                            </div> <!-- end col -->
                        </div>
                        <!-- end row-->

                    </div> <!-- container -->

                </div> <!-- content -->



<script type="text/javascript">
	
	$(document).ready(function(){
		$('#image').change(function(e){
			var reader = new FileReader();
			reader.onload =  function(e){
				$('#showImage').attr('src',e.target.result);
			}
			reader.readAsDataURL(e.target.files['0']);
		});
	});
</script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\S09_Project\pos\resources\views/backend/supplier/details_supplier.blade.php ENDPATH**/ ?>