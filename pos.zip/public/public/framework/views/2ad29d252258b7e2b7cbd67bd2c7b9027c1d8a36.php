
<?php $__env->startSection('admin'); ?>

 <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                        <a href="<?php echo e(url('backup/now')); ?>" class="btn btn-primary rounded-pill waves-effect waves-light"><i class="fa-solid fa-cloud-arrow-up"></i> &nbsp; Backup Now </a>   
                                        </ol>
                                    </div>
                                    <h4 class="page-title">All Backup</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">


                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>File Name </th>
                                <th>Size </th>
                                <th>Path</th> 
                                <th colspan = 2 >Download as zip file / Delete Backup</th>
                            </tr>
                        </thead>


        <tbody>
        	<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td> 
                <td><?php echo e($item->getFilename()); ?></td>
                <td><?php echo e($item->getSize()); ?></td>
                <td><?php echo e($item->getPath()); ?></td> 
                <td colspan = 2 >

                <a href="<?php echo e(url($item->getFilename())); ?>" class="btn btn-blue rounded-pill waves-effect waves-light"><i class="fa-solid fa-download"></i> &nbsp; Download </a> &nbsp;

                <a href=" <?php echo e(url('delete/database/'.$item->getFilename())); ?>" class="btn btn-danger rounded-pill waves-effect waves-light" id="delete"><i class="fa-solid fa-trash"></i> &nbsp; Delete</a>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->




                    </div> <!-- container -->

                </div> <!-- content -->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\S09_Project\pos\resources\views/admin/db_backup.blade.php ENDPATH**/ ?>