<?php $__env->startSection('admin'); ?>

 <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
      <a href="<?php echo e(route('add.expense')); ?>" class="btn btn-primary rounded-pill waves-effect waves-light">Add Expense </a>  
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Month Expense</h4>
                                </div>
                            </div>
                        </div>     


                        <!-- end page title --> 

    <?php
    $month = date("F");
    $expensemonth = App\Models\Expense::where('month',$month)->sum('amount');
    ?>


    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

           <h4 class="header-title"> Month Expense </h4>   
           <h4 style="color:black; font-size: 30px;" align="center"> Total : Rs . <?php echo e($expensemonth); ?></h4>      
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Expense ID</th>
                                <th>Details</th>
                                <th>Amount</th>
                                <th>Month</th>  
                            </tr>
                        </thead>


        <tbody>
        	<?php $__currentLoopData = $monthexpense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($item->details); ?></td>
                <td><?php echo e($item->amount); ?></td>
                <td><?php echo e($item->month); ?></td> 

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->




                    </div> <!-- container -->

                </div> <!-- content -->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\S09_Project\pos\resources\views/backend/expense/month_expense.blade.php ENDPATH**/ ?>